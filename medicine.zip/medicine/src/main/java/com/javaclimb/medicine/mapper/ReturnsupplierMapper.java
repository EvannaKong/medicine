package com.javaclimb.medicine.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.javaclimb.medicine.entity.Returngoods;
import com.javaclimb.medicine.entity.Returnsupplier;

//药品收到退货记录的增删改查
public interface ReturnsupplierMapper extends BaseMapper<Returnsupplier> {

}
