package com.javaclimb.medicine.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.javaclimb.medicine.entity.Billinfo;
import com.javaclimb.medicine.entity.Returngoods;

//账单信息的增删改查
public interface BillinfoMapper extends BaseMapper<Billinfo> {

}
