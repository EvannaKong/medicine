package com.javaclimb.medicine.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;

import com.javaclimb.medicine.entity.Owinfo;

//药品出库表的增删改查
public interface OwinfoMapper extends BaseMapper<Owinfo> {

}
