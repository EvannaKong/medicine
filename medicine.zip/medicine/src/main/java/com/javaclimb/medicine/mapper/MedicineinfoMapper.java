package com.javaclimb.medicine.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.javaclimb.medicine.entity.Medicineinfo;
import com.javaclimb.medicine.entity.Supplier;

//药品表的增删改查
public interface MedicineinfoMapper extends BaseMapper<Medicineinfo> {

}
