package com.javaclimb.medicine.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.javaclimb.medicine.entity.User;
//用户表的增删改查
public interface UserMapper extends BaseMapper<User> {

}
