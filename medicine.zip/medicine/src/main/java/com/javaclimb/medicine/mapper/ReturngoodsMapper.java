package com.javaclimb.medicine.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.javaclimb.medicine.entity.Returngoods;
import com.javaclimb.medicine.entity.Saleinfo;

//药品收到退货记录的增删改查
public interface ReturngoodsMapper extends BaseMapper<Returngoods> {

}
