package com.javaclimb.medicine.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.javaclimb.medicine.entity.Owinfo;
import com.javaclimb.medicine.entity.Saleinfo;

//药品销售记录的增删改查
public interface SaleinfoMapper extends BaseMapper<Saleinfo> {

}
