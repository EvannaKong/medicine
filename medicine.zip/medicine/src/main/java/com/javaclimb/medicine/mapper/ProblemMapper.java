package com.javaclimb.medicine.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;

import com.javaclimb.medicine.entity.Problem;

//问题要拍的增删改查
public interface ProblemMapper extends BaseMapper<Problem> {

}
